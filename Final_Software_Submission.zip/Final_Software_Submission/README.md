VizGenie @ May 2021

The link to the running website is:

    http://vizgenie.ddns.net/


The information below is for running the website on localhost.

    Requirements: Nodejs (current stable version (14.17.0 LTS)), Python (version 3.5+)

    To run the webserver, enter the following command in the terminal: 
        
        node server.js

    Default port is 80. (localhost:80)
    To change the port, edit the port constant in the server.js file (Line 84).